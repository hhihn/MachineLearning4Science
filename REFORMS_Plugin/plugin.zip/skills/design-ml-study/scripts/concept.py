#!/usr/bin/env python3
"""Maintain a user-grounded study plan and export its confirmed contents to DOCX.

This script checks structure and provenance fields. It cannot establish whether
user evidence is authentic or scientific decisions are sound. The coach must
check both against the actual conversation before exporting a final plan.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
CATALOG = json.loads((SKILL_ROOT / "references" / "catalog.json").read_text(encoding="utf-8"))
CORE_IDS = [row["id"] for row in CATALOG["core_fields"]]
ITEM_IDS = [row["id"] for row in CATALOG["items"]]
MODULE_IDS = [row["id"] for row in CATALOG["modules"]]
STATUSES = {"unanswered", "proposed", "deferred", "conflict", "confirmed", "not_applicable"}
PLACEHOLDER = re.compile(r"^(?:tbd|todo|offen|unbekannt|unknown|pending|noch unklar|weiß ich nicht|weiss ich nicht|n/?a|[.\u2026?\-]+)$", re.I)


def text_ok(value):
    return isinstance(value, str) and bool(value.strip()) and not PLACEHOLDER.fullmatch(value.strip())


def evidence_ok(value):
    return isinstance(value, list) and bool(value) and all(text_ok(entry) for entry in value)


def initial_state():
    def record(item=False):
        result = {"status": "unanswered", "text": "", "user_evidence": [], "rationale": ""}
        if item:
            result.update(implementation_status="", evidence_plan="")
        return result
    return {
        "revision": 1,
        "core": {key: record() for key in CORE_IDS},
        "items": {key: record(True) for key in ITEM_IDS},
        "conflicts": [],
        "final_review": {"status": "unanswered", "reviewed_revision": None, "reviewed_digest": None, "user_evidence": []},
        "labels": {},
    }


def language_labels(code):
    # This is an explicitly requested label template, not a project default.
    if code == "de":
        result = {
            "language": "Deutsch", "untitled": "Forschungskonzept mit noch offenem Titel",
            "final": "Abgestimmtes Forschungskonzept", "draft": "Unvollständiger Arbeitsstand",
            "revision": "Konzeptstand", "stage": "Projektstadium",
            "intro": "Dieses Konzept beschreibt die vereinbarte wissenschaftliche Fragestellung und das Vorgehen mit maschinellem Lernen. Bei jedem Prüfpunkt werden die Entscheidung, ihre Begründung und der vorhandene oder geplante Nachweis getrennt angegeben.",
            "research": "Forschungsfrage und wissenschaftliche Aussage",
            "context": "Rahmen der Untersuchung", "rationale": "Begründung",
            "proof": "Nachweis", "planned": "Geplant", "existing": "Vorhanden",
            "not_applicable": "Begründet nicht anwendbar", "confirmed": "Bestätigt",
            "unanswered": "Noch nicht beantwortet", "proposed": "Unbestätigter Vorschlag",
            "deferred": "Zurückgestellt", "conflict": "Ungeklärter Konflikt",
            "missing": "Noch offen", "implementation": "Umsetzung und ausstehende Nachweise",
            "implementation_intro": "Bei den folgenden Prüfpunkten sind die vereinbarten Maßnahmen oder Nachweise noch umzusetzen. Die konkreten Schritte stehen im jeweiligen Abschnitt.",
            "no_planned": "Es sind keine Nachweise als noch zu planen erfasst. Dies ist kein unabhängiger Nachweis der Umsetzung.",
            "open": "Offene Entscheidungen und Konflikte", "no_open": "Die protokollierten Grundentscheidungen sind beantwortet. Ausstehende Umsetzungsnachweise bleiben im Konzept als geplant gekennzeichnet.",
            "mapping": "Anhang mit der Zuordnung zu REFORMS",
            "id": "Item", "topic": "Thema", "status": "Status", "location": "Abschnitt",
            "sources": "Quellen und Entscheidungsgrundlage",
            "source_report": "Fachliche Grundlage ist der bereitgestellte REFORMS Report. Die Fragen und die Dokumentstruktur sind eine Operationalisierung für die gemeinsame Forschungsplanung.",
            "source_primary": "Originalpublikation zur Zuordnung der 32 Items",
            "user_sources": "Dokumentierte Nutzerantworten und Bestätigungen",
            "incomplete_record": "Antwort, Begründung oder Nutzerbeleg noch unvollständig",
            "review_pending": "Abschließende Bestätigung des aktuellen Konzeptstands noch offen",
            "planned_note": "Geplante Maßnahmen belegen noch keine Durchführung oder erfolgreiche Validierung. Die itembezogene Zuordnung ist keine Zertifizierung.",
        }
    elif code == "en":
        result = {
            "language": "English", "untitled": "Research concept with title pending",
            "final": "Agreed research concept", "draft": "Incomplete working draft",
            "revision": "Concept revision", "stage": "Study stage",
            "intro": "This concept describes the agreed scientific question and machine learning study design. Each checklist item distinguishes the decision, its rationale, and existing or planned evidence.",
            "research": "Research question and scientific claim", "context": "Study context",
            "rationale": "Rationale", "proof": "Evidence", "planned": "Planned", "existing": "Existing",
            "not_applicable": "Not applicable with rationale", "confirmed": "Confirmed",
            "unanswered": "Not yet answered", "proposed": "Unconfirmed proposal",
            "deferred": "Deferred", "conflict": "Unresolved conflict", "missing": "Still open",
            "implementation": "Implementation and pending evidence",
            "implementation_intro": "The agreed measures or evidence for the following items remain to be completed. The relevant section describes the specific steps.",
            "no_planned": "No evidence has been recorded as pending. This does not independently demonstrate implementation.",
            "open": "Open decisions and conflicts",
            "no_open": "The recorded fundamental decisions have been answered. Pending implementation evidence remains explicitly marked as planned.",
            "mapping": "Appendix mapping the concept to REFORMS",
            "id": "Item", "topic": "Topic", "status": "Status", "location": "Section",
            "sources": "Sources and decision provenance",
            "source_report": "The supplied REFORMS report provides the methodological basis. The questions and document structure operationalize it for collaborative research planning.",
            "source_primary": "Original publication for the 32 item identifiers",
            "user_sources": "Recorded user answers and confirmations",
            "incomplete_record": "Answer, rationale, or user evidence is incomplete",
            "review_pending": "Final confirmation of the current concept is still pending",
            "planned_note": "Planned measures do not establish implementation or successful validation. The item mapping is not a certification.",
        }
    else:
        raise ValueError("Use de or en for a template, or supply fully translated labels in the state.")
    result["core"] = {row["id"]: row[code] for row in CATALOG["core_fields"]}
    result["items"] = {row["id"]: row[code] for row in CATALOG["items"]}
    result["modules"] = {row["id"]: row[code] for row in CATALOG["modules"]}
    return result


def fingerprint(state):
    """Bind final confirmation to the exact recorded concept, not just a counter."""
    snapshot = {key: state.get(key) for key in ("revision", "core", "items", "conflicts", "labels")}
    raw = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def label_errors(state):
    labels = state.get("labels")
    if not isinstance(labels, dict):
        return ["labels: expected localized labels object"]
    errors = []
    for key, value in language_labels("en").items():
        supplied = labels.get(key)
        if isinstance(value, dict):
            if not isinstance(supplied, dict) or set(supplied) != set(value):
                errors.append(f"labels.{key}: provide every translated title")
            elif not all(text_ok(title) for title in supplied.values()):
                errors.append(f"labels.{key}: translated titles cannot be empty")
        elif not text_ok(supplied):
            errors.append(f"labels.{key}: localized text is required")
    core = state.get("core", {})
    language = core.get("document_language", {}) if isinstance(core, dict) else {}
    if isinstance(language, dict) and text_ok(language.get("text")):
        if labels.get("language", "").strip().casefold() != language["text"].strip().casefold():
            errors.append("labels.language: must match the user-confirmed document language wording")
    else:
        errors.append("core.document_language: the user must specify the document language")
    if not isinstance(language, dict) or language.get("status") != "confirmed" or not evidence_ok(language.get("user_evidence")):
        errors.append("core.document_language: explicit user confirmation is required even for a draft")
    return errors


def check_state(state):
    if not isinstance(state, dict):
        return ["state: expected a JSON object"]
    errors = []
    revision = state.get("revision")
    if type(revision) is not int or revision < 1:
        errors.append("revision: expected a positive integer")
    for group, ids in (("core", CORE_IDS), ("items", ITEM_IDS)):
        records = state.get(group)
        if not isinstance(records, dict):
            errors.append(f"{group}: expected an object")
            continue
        if set(records) != set(ids):
            missing = sorted(set(ids) - set(records))
            extra = sorted(set(records) - set(ids))
            errors.append(f"{group}: identifiers differ; missing={missing}, extra={extra}")
        for key in ids:
            record = records.get(key)
            prefix = f"{group}.{key}"
            if not isinstance(record, dict):
                errors.append(f"{prefix}: missing record")
                continue
            status = record.get("status")
            if status not in STATUSES:
                errors.append(f"{prefix}: invalid status")
            allowed = {"confirmed", "not_applicable"} if group == "items" else {"confirmed"}
            if status not in allowed:
                errors.append(f"{prefix}: unresolved fundamental answer or item ({status})")
            if not text_ok(record.get("text")):
                errors.append(f"{prefix}: a concrete answer or agreed plan is required")
            if not evidence_ok(record.get("user_evidence")):
                errors.append(f"{prefix}: actual user evidence is required")
            if group == "items":
                if not text_ok(record.get("rationale")):
                    errors.append(f"{prefix}: a study-specific rationale is required")
                if not text_ok(record.get("evidence_plan")):
                    errors.append(f"{prefix}: existing or planned evidence must be specified")
                implementation = record.get("implementation_status")
                allowed_impl = {"not_applicable"} if status == "not_applicable" else {"planned", "existing"}
                if implementation not in allowed_impl:
                    errors.append(f"{prefix}: implementation status does not match item status")
    conflicts = state.get("conflicts")
    if not isinstance(conflicts, list):
        errors.append("conflicts: expected a list")
    else:
        for index, conflict in enumerate(conflicts):
            if not isinstance(conflict, dict) or not text_ok(conflict.get("description")):
                errors.append(f"conflicts.{index}: a concrete description is required")
            if not isinstance(conflict, dict) or conflict.get("status") != "resolved" or not text_ok(conflict.get("resolution")):
                errors.append(f"conflicts.{index}: unresolved conflict")
    review = state.get("final_review")
    if not isinstance(review, dict) or review.get("status") != "confirmed":
        errors.append("final_review: explicit confirmation of the current concept is required")
    elif type(review.get("reviewed_revision")) is not int or review.get("reviewed_revision") != revision or not evidence_ok(review.get("user_evidence")) or review.get("reviewed_digest") != fingerprint(state):
        errors.append("final_review: confirmation must cite the actual user response for this revision")
    errors.extend(label_errors(state))
    return errors


def _border_table(table):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    properties = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border = OxmlElement(f"w:{edge}")
        for key, value in (("val", "single"), ("sz", "4"), ("color", "D9D9D9")):
            border.set(qn(f"w:{key}"), value)
        borders.append(border)
    properties.append(borders)
    for row_index, row in enumerate(table.rows):
        props = row._tr.get_or_add_trPr()
        if row_index == 0:
            props.append(OxmlElement("w:tblHeader"))
        # Allow long content rows to break, avoiding blank half pages.
        for cell in row.cells:
            cell.vertical_alignment = 1
            margins = OxmlElement("w:tcMar")
            for edge in ("top", "left", "bottom", "right"):
                el = OxmlElement(f"w:{edge}")
                el.set(qn("w:w"), "100")
                el.set(qn("w:type"), "dxa")
                margins.append(el)
            cell._tc.get_or_add_tcPr().append(margins)
            if row_index == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "E9EFF4")
                cell._tc.get_or_add_tcPr().append(shade)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = 0
                paragraph.paragraph_format.line_spacing = 1.05
                paragraph.paragraph_format.keep_with_next = False
                for run in paragraph.runs:
                    run.bold = row_index == 0


def export_docx(state, output, draft=False):
    errors = check_state(state)
    if errors and not draft:
        raise ValueError("Final export blocked:\n" + "\n".join(errors))
    # A draft must still have a confirmed language and well-formed containers.
    if draft:
        if not isinstance(state, dict):
            raise ValueError("A draft also requires a state object.")
        hard_errors = label_errors(state)
        for group in ("core", "items"):
            if not isinstance(state.get(group), dict) or any(not isinstance(v, dict) for v in state[group].values()):
                hard_errors.append(f"{group}: malformed records cannot be exported")
        if hard_errors:
            raise ValueError("Draft export blocked:\n" + "\n".join(hard_errors))
    output = Path(output)
    if output.suffix.lower() != ".docx":
        raise ValueError("The output must have the .docx extension.")
    if output.exists():
        raise ValueError("Output exists; choose a new revision filename to preserve it.")
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as error:
        raise ValueError("DOCX export requires python-docx in the active runtime.") from error
    labels = state["labels"]
    core, items = state["core"], state["items"]
    doc = Document()
    # Bundled Word templates can carry a colored title rule in paragraph styles.
    # Remove it rather than relying on a renderer-specific default.
    for style in doc.styles:
        for border in style.element.xpath(".//w:pBdr"):
            border.getparent().remove(border)
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(0.72)
    section.left_margin = section.right_margin = Inches(0.8)
    for name in ("Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3"):
        style = doc.styles[name]
        style.font.name = "Arial"
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.font.underline = False
    normal = doc.styles["Normal"]
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.12
    doc.styles["Title"].font.size = Pt(23)
    for name, size in (("Heading 1", 15), ("Heading 2", 12)):
        style = doc.styles[name]
        style.font.size = Pt(size)
        style.paragraph_format.space_before = Pt(13 if name == "Heading 1" else 9)
        style.paragraph_format.space_after = Pt(6)
        style.paragraph_format.keep_with_next = True
    doc.core_properties.author = ""
    doc.core_properties.last_modified_by = ""
    project_title = core.get("project_title", {}).get("text")
    doc.add_paragraph(project_title if text_ok(project_title) else labels["untitled"], "Title")
    doc.add_paragraph(labels["draft" if draft else "final"], "Subtitle")
    doc.add_paragraph(f'{labels["revision"]} {state.get("revision", "")}', "Normal")
    doc.add_paragraph(labels["intro"])
    stage = core.get("study_stage", {}).get("text")
    if text_ok(stage):
        doc.add_paragraph(f'{labels["stage"]}: {stage}')

    def paragraph(text, keep_with_next=False):
        if not text_ok(text):
            text = labels["missing"]
        # Preserve explicit paragraph breaks without interpreting input as markup.
        for part in text.split("\n\n"):
            para = doc.add_paragraph(part)
            para.paragraph_format.keep_with_next = keep_with_next

    def core_section(heading, ids):
        doc.add_heading(heading, level=1)
        for key in ids:
            doc.add_heading(labels["core"][key], level=2)
            record = core.get(key, {})
            if draft and record.get("status") != "confirmed":
                paragraph(labels.get(record.get("status"), labels["missing"]))
            paragraph(record.get("text"))

    core_section(labels["research"], ["research_question", "scientific_claim", "ml_role", "evidence_logic"])
    core_section(labels["context"], ["information_context", "independent_unit", "dependency_structure", "resources_constraints", "access_and_governance"])

    for module in CATALOG["modules"]:
        doc.add_heading(f'{module["id"]} {labels["modules"][module["id"]]}', level=1)
        for item in CATALOG["items"]:
            if item["module"] != module["id"]:
                continue
            key = item["id"]
            record = items.get(key, {})
            doc.add_heading(f'{key} {labels["items"][key]}', level=2)
            if draft or record.get("status") == "not_applicable":
                paragraph(labels.get(record.get("status"), labels["missing"]), keep_with_next=True)
            paragraph(record.get("text"), keep_with_next=True)
            paragraph(f'{labels["rationale"]}: {record.get("rationale") or labels["missing"]}', keep_with_next=True)
            phase = labels.get(record.get("implementation_status"), labels["missing"])
            paragraph(f'{labels["proof"]} ({phase}): {record.get("evidence_plan") or labels["missing"]}')

    doc.add_heading(labels["implementation"], level=1)
    planned = [key for key in ITEM_IDS if items.get(key, {}).get("implementation_status") == "planned"]
    paragraph(labels["implementation_intro"] if planned else labels["no_planned"])
    if planned:
        paragraph(", ".join(planned))
    paragraph(labels["planned_note"])
    doc.add_heading(labels["open"], level=1)
    if errors:
        # Show the affected field with a localized, human-readable label.
        for key in CORE_IDS:
            record = core.get(key, {})
            if any(error.startswith(f"core.{key}:") for error in errors):
                issue = labels["incomplete_record"] if record.get("status") == "confirmed" else labels.get(record.get("status"), labels["missing"])
                paragraph(f'{labels["core"][key]}: {issue}')
        for key in ITEM_IDS:
            record = items.get(key, {})
            if any(error.startswith(f"items.{key}:") for error in errors):
                issue = labels["incomplete_record"] if record.get("status") in {"confirmed", "not_applicable"} else labels.get(record.get("status"), labels["missing"])
                paragraph(f'{key} {labels["items"][key]}: {issue}')
        for conflict in state.get("conflicts", []):
            if isinstance(conflict, dict) and conflict.get("status") != "resolved":
                paragraph(f'{labels["conflict"]}: {conflict.get("description", labels["missing"])}')
        if any(error.startswith("final_review:") for error in errors):
            paragraph(labels["review_pending"])
    else:
        paragraph(labels["no_open"])

    doc.add_heading(labels["mapping"], level=1)
    table = doc.add_table(rows=1, cols=4)
    table.autofit = False
    widths = [0.48, 3.2, 1.65, 1.17]
    for column, width in zip(table.columns, widths):
        column.width = Inches(width)
    for cell, key in zip(table.rows[0].cells, ("id", "topic", "status", "location")):
        cell.text = labels[key]
    for item in CATALOG["items"]:
        key = item["id"]
        record = items.get(key, {})
        cells = table.add_row().cells
        values = [key, labels["items"][key], labels.get(record.get("status"), labels["missing"]), key]
        for cell, value, width in zip(cells, values, widths):
            cell.text = value
            cell.width = Inches(width)
    _border_table(table)

    doc.add_heading(labels["sources"], level=1)
    paragraph(labels["source_report"])
    paragraph(labels["source_primary"])
    paragraph("Kapoor S et al. 2024. REFORMS: Consensus-based Recommendations for Machine-learning-based Science. Science Advances 10, eadk3452. https://doi.org/10.1126/sciadv.adk3452")
    doc.add_heading(labels["user_sources"], level=2)
    seen = set()
    evidence = []
    for group in (core, items):
        for record in group.values():
            evidence.extend(record.get("user_evidence", []))
    evidence.extend(state.get("final_review", {}).get("user_evidence", []))
    for entry in evidence:
        if isinstance(entry, str) and entry.strip() and entry not in seen:
            seen.add(entry)
            paragraph(entry)
    if not seen:
        paragraph(labels["missing"])
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(output))
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="Create a state with no assumed project answers")
    init.add_argument("state")
    labels = commands.add_parser("labels", help="Print explicitly selected label templates")
    labels.add_argument("language", choices=["de", "en"])
    check = commands.add_parser("check", help="Check whether all fundamental answers are recorded")
    check.add_argument("state")
    review = commands.add_parser("fingerprint", help="Identify the exact concept presented for final user confirmation")
    review.add_argument("state")
    export = commands.add_parser("export", help="Create a DOCX from the recorded answers")
    export.add_argument("state")
    export.add_argument("output")
    export.add_argument("--draft", action="store_true", help="Explicit incomplete draft; never a final concept")
    args = parser.parse_args()
    try:
        if args.command == "init":
            path = Path(args.state)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x", encoding="utf-8") as stream:
                json.dump(initial_state(), stream, ensure_ascii=False, indent=2)
            print(path.resolve())
        elif args.command == "labels":
            print(json.dumps(language_labels(args.language), ensure_ascii=False, indent=2))
        else:
            state = json.loads(Path(args.state).read_text(encoding="utf-8"))
            if args.command == "fingerprint":
                if not isinstance(state, dict):
                    raise ValueError("Expected a state object.")
                print(fingerprint(state))
                return 0
            if args.command == "check":
                errors = check_state(state)
                print(json.dumps({"ready_for_document": not errors, "errors": errors}, ensure_ascii=False, indent=2))
                return 2 if errors else 0
            print(export_docx(state, args.output, args.draft).resolve())
        return 0
    except (OSError, ValueError, TypeError, AttributeError, KeyError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
