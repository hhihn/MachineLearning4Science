# Methodische Leitplanken

Der Nutzerreport ist die fachliche Grundlage. Seine didaktischen Zuspitzungen nicht als ausnahmslose mathematische, rechtliche oder redaktionelle Vorschriften wiedergeben. Die folgenden Präzisierungen sind Coaching-Hinweise, keine weiteren offiziellen REFORMS-Items. Projektspezifische Entscheidungen weiterhin erfragen.

## Geltungsbereich und Aussage

- Zuerst die wissenschaftliche Behauptung und die Evidenz klären, dann die ML-Aufgabe. Ein Algorithmus allein ist kein Forschungsdesign.
- Prädiktive Leistung ist kein hinreichender Beleg für Kausalität, Mechanismen oder Konstruktvalidität. Auch klassische statistische Verfahren können für Vorhersage eingesetzt werden.
- Die Report-Items als anpassbare Empfehlungen für die konkrete Studie behandeln. Eine begründete Nichtanwendbarkeit mit Nutzerbestätigung ist möglich; keine mechanische Anforderung aller Items für alle Lernparadigmen.
- Eine vollständig dokumentierte Planung ist kein Nachweis ihrer Umsetzung und keine Garantie für Reproduzierbarkeit oder externe Validität.

## Trennung von Entwicklung und Evaluation

- Zur Modellauswahl und abschließenden Bewertung unabhängige Information verwenden. Nested CV ist eine mögliche Lösung. Ein unangetasteter finaler Testdatensatz mit ausschließlich auf Entwicklungsdaten vorgenommener Auswahl ist ebenfalls eine mögliche Lösung. Den im Report an einer Stelle verwendeten Ausschließlichkeitsanspruch für Nested CV nicht übernehmen.
- CV-Ergebnisse, die selbst zur Modellauswahl dienten, können optimistisch sein. Sie nicht als unabhängige abschließende Performance ausgeben.
- Vorverarbeitung mit gelernten Parametern ausschließlich am jeweiligen Trainingsanteil anpassen. Dazu zählen Imputation, Skalierung, Feature-Auswahl, datenbasierte Schwellen, Embedding-Anpassungen und Resampling einschließlich SMOTE. Auch im Tuning in die Pipeline innerhalb der Folds einbetten.
- Feste Transformationen ohne gelernte Parameter von datenadaptiven Transformationen unterscheiden. Eine aus Gesamtdaten ausgewählte vermeintlich feste Transformation kann dennoch Auswahl-Leakage verursachen.
- Abhängigkeiten und Generalisierungsziel bestimmen die Splits: Personen, Zentren, Orte, Geräte, Zeit und überlappende Fenster berücksichtigen. Nicht jede Zeitreihe rechtfertigt denselben Split oder dieselbe Blocklücke; die konkrete Aufgabe erfragen.
- Eine finale Testauswertung darf nicht nachträglich für Modellwahl, Prompts, Feature-Engineering, Schwellen oder Budgetentscheidungen benutzt werden. Bereits erfolgte Nutzung offenlegen und ein glaubwürdiges weiteres Evaluationsdesign klären.

## Metriken und Unsicherheit

- Metriken auf Forschungsfrage, Prävalenz, Fehlerkosten und Entscheidungssituation beziehen. Accuracy bei Ungleichgewicht kritisch einordnen, aber keine bestimmte Ersatzmetrik automatisch vorschreiben.
- Fold-Streuung ist kein Konfidenzintervall und berücksichtigt nicht automatisch alle Abhängigkeiten oder den Selektionsprozess.
- Bei Bootstrap beziehungsweise anderen Resampling-Verfahren die unabhängige Einheit respektieren; Cluster oder Personen gegebenenfalls gemeinsam ziehen. Bei Zeitabhängigkeit passende Verfahren diskutieren.
- Variation zwischen Seeds, Unsicherheit der Populationsperformance und Unsicherheit einer individuellen Vorhersage auseinanderhalten.
- Unsicherheit von ML-Messungen bei nachgelagerter wissenschaftlicher Auswertung berücksichtigen, wenn für die Aussage relevant. Das Verfahren und dessen Annahmen erfragen.
- Statistische Tests nur bei begründeter Vergleichsfrage planen. Testannahmen, Paarung, Mehrfachvergleiche, Effektgröße und Unsicherheit berücksichtigen. Nicht aus p-Werten allein fachliche Relevanz ableiten.

## Baselines und Aussagegrenzen

- Faire Vergleiche benötigen dieselben zulässigen Informationen, Evaluation und vergleichbar begründete Optimierung. Bei einem parameterfreien Dummy kein künstliches Tuning verlangen.
- Externe Validierung ist kontextbezogen zu begründen. Ein einziger externer Datensatz oder eine hohe Testleistung belegt keine universelle Übertragbarkeit.
- Bei eingeschränkten Ressourcen den wissenschaftlichen Anspruch und das Design gemeinsam anpassen. Eine kleine Stichprobe nicht allein wegen eines vorhandenen ML-Werkzeugs für ausreichend erklären.

## Reproduzierbarkeit

- Versionen, Seeds und Umgebungen dokumentieren, soweit tatsächlich bekannt oder als verbindlicher Erfassungsplan festgelegt. Seeds und Temperature 0 garantieren keine bitweise Wiederholbarkeit.
- Bei LLMs Modell- und API-Kennungen, Zeitpunkt, Prompts, Aufrufparameter, zugängliche Outputs und Änderungen dokumentieren. Nicht einsehbare Trainingsdaten und Anbieteränderungen als Grenzen behandeln.
- Datenzugriff und Freigaben nicht mit öffentlicher Verfügbarkeit gleichsetzen. Geschützte Originaldaten erfordern eine nachvollziehbare Zugangs- oder Prüfstrategie. Synthetische Beispiele können Ausführbarkeit zeigen, aber keine Originalresultate validieren.
- Weder DOI noch öffentliche Veröffentlichung oder ein Ethikvotum aus dem Report pauschal als bereits erfüllte Verpflichtung jeder Studie ableiten. Einschlägige Bedingungen vom User klären lassen. Bei aktuellen Rechtsfragen aktuelle zuständige Primärquellen prüfen, ohne ungeprüfte Rechtsberatung in das Konzept einzubauen.
