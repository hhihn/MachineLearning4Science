# Vorgaben für das Word Konzept

## Ziel und Status

Ein fachlich lesbares Forschungskonzept als DOCX erstellen. Den Zusammenhang zwischen Forschungsfrage, wissenschaftlicher Aussage und ML-Auswertung erklären. Die Hauptabschnitte als zusammenhängenden Text mit klaren Überschriften schreiben. Die REFORMS-Zuordnung im Anhang als kompakte Tabelle führen.

Bei einem geplanten Projekt ausschließlich Pläne formulieren. Bei einem laufenden Projekt bereits belegte Schritte von geplanten Schritten unterscheiden. Das Dokument enthält keinen erfundenen Ergebnisteil und keine angebliche Bestätigung erfolgreicher Reproduzierbarkeit.

Ein „abschließendes Konzept“ bezeichnet den vollständig geklärten Planungsstand. Es ist keine Zertifizierung nach REFORMS und kein Nachweis der Durchführung. Die ausdrückliche Bestätigung des letzten konkreten Konzeptstands muss protokolliert sein.

## Inhalt

1. Projekttitel und Status des Konzeptstands.
2. Wissenschaftliche Frage, angestrebte Aussage, ML-Rolle und Beleglogik.
3. Grundlegender Kontext mit Information zum Mess- oder Vorhersagezeitpunkt, unabhängigen Einheiten, Abhängigkeiten, Ressourcen und Datenzugang.
4. Alle acht Module aus dem Report. Pro Item die bestätigte Entscheidung, ihre Begründung und den bestehenden oder geplanten Nachweis ausformulieren. Inhaltlich verwandte Passagen dürfen redaktionell verbunden werden, wenn die Zuordnung erhalten bleibt.
5. Ausstehende Nachweise und Umsetzungsschritte mit Bezug auf die Entscheidungen. Verantwortlichkeiten und Termine nur nennen, wenn der User sie angegeben hat.
6. Grenzen und offene Fragen. In einem finalen Plan dürfen ausstehende Umsetzungsnachweise stehen, aber keine unbeantworteten relevanten Grundentscheidungen oder ungeklärten methodischen Konflikte.
7. Anhang mit genau 32 Zeilen: Report-ID, Thema, Status und konkrete Fundstelle im Konzept. Nichtanwendbarkeit mit Begründung im betreffenden Abschnitt ausweisen.
8. Nachvollziehbare Quellen und die für Entscheidungen verwendeten Nutzerbelege.

Der gebündelte Generator erzeugt diese Struktur und übernimmt die bestätigten Texte unverändert. Die Qualität und Vollständigkeit dieser Texte vor dem Export prüfen. Nicht mit reinem Stichwortmaterial einen scheinbar ausformulierten Plan erzeugen.

## Sprache und Gestaltung

- Gewählte Dokumentsprache für Überschriften und Fließtext verwenden; keine andere Sprache aus Defaults ergänzen.
- Sachlich und lesbar schreiben, passend zur erfragten ML-Erfahrung. Begriffe bei Bedarf kurz erklären.
- Alle wissenschaftlichen Werte und Entscheidungen auf Nutzerantworten zurückführen. Stilistische Verknüpfungen dürfen keine neue Entscheidung oder Tatsachenbehauptung einführen.
- Einfache, professionelle Word-Formatvorlagen nutzen; Titel und Überschriften schwarz, lesbare Grundschrift, großzügige Abstände, klare Tabellenköpfe.
- Titel konkret formulieren; keine dekorativen Linien oder erfundenen Logos und Institutionen verwenden.
- Word erzeugen und das aktuelle Ergebnis mit der verfügbaren DOCX-Renderfunktion als Seitenbilder visuell prüfen. Tabellen mit wiederholter Kopfzeile und sauberen Umbrüchen gestalten. Interne Prüf-PDFs und Bilder nicht ausliefern.

## Abschlussprüfung

- Alle 14 grundlegenden Projektfelder und alle 32 Report-Items besitzen gültige Antworten oder eine zulässige begründete Nichtanwendbarkeit.
- Nutzerbelege und finale Bestätigung sind vorhanden; die Bestätigung gehört zur aktuellen Revision.
- Forschungsfrage, Zielpopulation, Messeinheit, Informationszeitpunkt und Evaluationsdesign passen zueinander.
- Keine Testdaten beeinflussen Vorverarbeitung, Modellwahl oder Tuning. Abhängigkeiten werden berücksichtigt.
- Metriken, Unsicherheiten und Grenzen tragen die angestrebte Aussage; Kausalität wird nicht aus Vorhersageleistung abgeleitet.
- Tatsachen, Pläne, ausstehende Nachweise und offene Fragen sind korrekt bezeichnet.
- Word-Datei existiert, wurde gerendert und wurde visuell geprüft.

Wenn eine Grundfrage offen ist, mit genau der nächsten entscheidungsrelevanten Rückfrage zum Gespräch zurückkehren. Ein automatisch erzeugter Prüfbericht ersetzt diese Rückfrage nicht.
