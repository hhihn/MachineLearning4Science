# Interviewleitfaden

## Inhalt

1. Sokratische Gesprächsführung
2. Forschungslogik
3. Daten und Messung
4. Evaluationsdesign
5. Modellierung und Unsicherheit
6. Reproduzierbarkeit und Grenzen
7. Sonderfälle und Abschluss

## Sokratische Gesprächsführung

Ein Gespräch führen, keinen starren Fragebogen abarbeiten. Eine eindeutige Nutzerantwort kann mehrere Felder und Prüfpunkte abdecken. Pro Schritt die noch ungeklärte Frage wählen, von der die nächste Entscheidung abhängt. Ein bis drei erklärende Sätze reichen meist aus.

Mit dem Muster arbeiten: Antwort kurz aufnehmen → deren methodische Konsequenz erklären → eine gezielte Frage stellen → Antwort abwarten. Bei einem Widerspruch zunächst den Widerspruch auflösen. Den User nicht auf eine vorab ausgewählte Methode hinlenken.

Geeignete Fragetypen:

- Klärung: „Was genau bedeutet X in deiner Untersuchung?“
- Begründung: „Warum wäre dieses Ergebnis ein Beleg für deine Behauptung?“
- Gegenbeispiel: „Welche alternative Erklärung könnte dieselbe Vorhersageleistung erzeugen?“
- Perspektivwechsel: „Welche Information hätte das Modell bei einer wirklich neuen Person?“
- Falsifizierbarkeit: „Welches Ergebnis würde gegen die Behauptung sprechen?“
- Geltungsgrenze: „Für welche Menschen, Orte oder Zeiträume soll diese Aussage gelten?“

Bei geringen ML-Kenntnissen zunächst die wissenschaftliche Bedeutung erklären. Beispielsweise nicht zuerst „Welche CV?“ fragen, sondern „Soll das Modell auf neue Personen, neue Orte oder zukünftige Messungen übertragbar sein?“ Danach passende Evaluationsoptionen erläutern und zur Auswahl stellen. Bei mehr Erfahrung präzise Terminologie verwenden, ohne Projektentscheidungen zu übernehmen.

Wenn der User die Antwort nicht kennt, Wissen und Entscheidung trennen. Fehlende Stichprobengröße braucht eine Datenerhebung oder Bestandsaufnahme, keinen geratenen Zahlenwert. Eine unbekannte Validierungsoption kann mit Beispielen erklärt werden. Bei echten Zielkonflikten Konsequenzen zeigen und eine Priorisierung erfragen.

## Forschungslogik

Leitfragen bedarfsabhängig einzeln stellen:

- Welche Forschungsfrage soll beantwortet werden? In welcher Disziplin und in welchem Projektstadium?
- Welche wissenschaftliche Aussage soll eine mögliche ML-Auswertung begründen? Ist sie explorativ oder vorab festgelegt?
- Welche Art Ergebnis wäre ein Beleg und welches ein Gegenbeleg? Gibt es eine fachliche Mindestanforderung, und wie wurde sie begründet?
- Welche Rolle soll ML haben: Vorhersage, Messung, Musterentdeckung, Suche, Erklärung oder etwas anderes?
- Warum ist dafür ML sinnvoll, und welche einfachere oder etablierte Alternative wäre wissenschaftlich relevant?
- Auf welche Population beziehungsweise Verteilung soll sich die Aussage beziehen? Warum gerade auf diese?
- Welche Information ist zur Beantwortung der Forschungsfrage notwendig, die eine hohe aggregierte Vorhersageleistung allein nicht liefert?

Kausale Aussagen nicht aus Vorhersagegüte oder Feature Importance herleiten. Falls das eigentliche Ziel kausal ist, nach Identifikationsstrategie, Studiendesign und Rolle des ML darin fragen. Die gemeinsame Entscheidung über eine Begrenzung oder Anpassung der Fragestellung dokumentieren.

## Daten und Messung

- Welche Daten sind vorhanden, geplant oder nur möglicherweise zugänglich? Welche Angaben sind bereits belegt?
- Woher stammen Trainings- und Evaluationsdaten, aus welchen Zeiträumen und Regionen und mit welchen Auswahlverfahren?
- Was ist die unabhängige Untersuchungseinheit? Wie viele Einheiten, Messungen und gegebenenfalls Klassen gibt es tatsächlich oder sollen erhoben werden?
- Gibt es Wiederholungsmessungen, gemeinsame Personen, Einrichtungen, Geräte, Chargen, Texte, Quellen, Zeitfenster oder räumliche Nachbarschaften?
- Welches theoretische Konstrukt wird durch welche beobachtete Zielgröße gemessen? Wie entstehen Labels, wer annotiert und wie wird die Zuverlässigkeit geprüft?
- Welche Merkmale sollen genutzt werden? Wann wären sie in der vorgesehenen Anwendung verfügbar?
- Wie wurden Daten erhoben und eingeschlossen? Was ist über Fehlwerte, Ausreißer, ungültige Werte und Duplikate bekannt?
- Inwiefern bildet der Stichprobenrahmen die Zielpopulation ab? Welche Gruppen oder Kontexte fehlen?

Bei geplanter Datenerhebung keine deskriptiven Werte verlangen, die noch nicht existieren. Stattdessen mit dem User festlegen, welche Kennwerte wann und wie ermittelt werden. Diese Felder als bestätigten Erhebungs- oder Analyseplan mit noch ausstehenden Nachweisen erfassen.

Keine Behauptung über Datenverteilung, Repräsentativität, Labelgüte, Unabhängigkeit oder Anonymität aus einem Dateinamen ableiten. Schemata und anonymisierte Auszüge genügen häufig für die Planung; keine unnötigen identifizierenden Daten anfordern.

## Evaluationsdesign

Das Generalisierungsziel vor dem Split-Verhältnis klären. Danach gemeinsam entscheiden:

- Welche Einheiten oder Zeitabschnitte müssen vollständig getrennt bleiben?
- Wurde ein vorgesehener Testdatensatz bereits für explorative Auswertungen, Modellwahl, Schwellenoptimierung oder wiederholte Vergleiche verwendet?
- Wie werden Entwicklung, Hyperparameterwahl und abschließende Evaluation getrennt?
- Welche Rolle haben externe Daten, wenn vorhanden? Sind sie zeitlich, räumlich oder nach Personen unabhängig?
- Welche Transformationen werden gelernt, wo werden sie angepasst und wie werden sie auf Evaluationsdaten angewendet?
- Welche Merkmale könnten Outcome-Proxies sein oder erst nach dem Vorhersagezeitpunkt entstehen?
- Wie werden Duplikate, Datensatzüberlappung und bei vortrainierten Modellen mögliche Kontamination geprüft?

Keinen generischen Zufallssplit bei unbekannten Abhängigkeiten empfehlen. Bei mehreren wissenschaftlichen Generalisierungszielen mehrere getrennte Auswertungen als Option diskutieren. Keine Fold-Zahl oder Testgröße eigenständig festlegen. Reicht die verfügbare Datenlage für das gewünschte Design nicht aus, nach einer Änderung des Anspruchs oder einer Nacherhebung fragen.

## Modellierung und Unsicherheit

- Welche Modelle und fachlichen Vergleichsverfahren sind angesichts Datenart, Fallzahl, Ressourcen und Forschungsziel sinnvoll?
- Welche triviale und welche fachlich aussagekräftige Baseline soll verwendet werden? Wie werden sie fair ausgewählt und gegebenenfalls optimiert?
- Was ist die Auswahlmetrik? Welche zusätzlichen Metriken sind für welche Fehlerarten oder Teilgruppen erforderlich?
- Welche Hyperparameter, Suchräume und Rechenbudgets werden geprüft? Wann wird die Suche beendet?
- Welche wissenschaftlich oder praktisch relevanten Fehlentscheidungen haben unterschiedliche Kosten? Wie werden Entscheidungsschwellen ohne Testset-Tuning festgelegt?
- Welche Art Unsicherheit soll quantifiziert werden: Stichprobenunsicherheit der Performance, Variation von Trainingsläufen, individuelle Prognoseunsicherheit oder nachgelagerte Schlussfolgerungen?
- Auf welcher unabhängigen Einheit wird resampelt? Welche Vergleiche sind gepaart und welche Annahmen werden geprüft?
- Gibt es mehrere ähnlich gute Modelle, deren Aussagen für einzelne Einheiten voneinander abweichen? Ist diese Multiplizität für den Claim relevant?

Metriken und Unsicherheit nicht automatisch aus „Klassifikation“ oder „Regression“ ableiten. Eine Methode nach Erklärung der Alternativen vom User auswählen lassen. Ein bestätigtes „kein Signifikanztest geplant, weil ...“ ist eine beantwortete Frage zu 7c und kann begründete Nichtanwendbarkeit darstellen.

## Reproduzierbarkeit und Grenzen

- Welche Software, Hardware, Kompetenzen, Zeit- und Rechenbudgets stehen zur Verfügung?
- Wie sollen Daten, Code, Umgebungen und Auswertungen versioniert und archiviert werden?
- Welche README-Anleitung und welches Reproduktionsskript werden bereitgestellt? Wer ist dafür zuständig, wenn bereits bekannt?
- Welche Freigaben, Lizenzen, Datenschutz- oder Ethikbedingungen sind einschlägig, und was ist tatsächlich geklärt?
- Was kann öffentlich bereitgestellt werden, was nur eingeschränkt, und welche überprüfbaren Alternativen sind möglich?
- Welche Übertragbarkeit wird empirisch geprüft und welche bleibt ein unbelegter Anspruch?
- Für welche Populationen, Zeiträume, Messbedingungen und Anwendungskontexte soll das Ergebnis ausdrücklich nicht gelten?

DOI, Repository, Ethikvotum, Nutzungsrechte und organisatorische Zusagen nicht erfinden. In der Konzeptphase einen konkreten Plan samt ausstehenden Nachweisen dokumentieren. Synthetische Daten nicht als gleichwertigen Ersatz einer Überprüfung auf Originaldaten darstellen.

## Sonderfälle und Abschluss

**Unüberwachtes Lernen:** Keine Zielvariable oder Klassen erzwingen. Nach wissenschaftlicher Bedeutung der Strukturen, Stabilität, Sensitivität, unabhängiger fachlicher Validierung und zulässigen Schlussfolgerungen fragen. Itembezogene Anpassungen und Nichtanwendbarkeit explizit bestätigen lassen.

**Suche oder Entdeckung:** Nach unabhängiger experimenteller oder fachlicher Validierung von Kandidaten fragen. Prädiktionsmetriken nur bei passender Teilaufgabe verwenden. Daten- und Code-Nachvollziehbarkeit weiterhin planen.

**Foundation Models und LLMs:** Modellkennung, Anbieter, Datum, API- und Promptversion, Decoding-Parameter, Wiederholungen, Cache, Retrieval, Auswahlverfahren und mögliche Testkontamination klären. Keine Reproduzierbarkeit durch Temperature 0 versprechen. Bei unbekanntem Pretraining-Datensatz eine dokumentierte Grenze festhalten.

**ML als Messinstrument:** Konstrukte und Validierung der Messung klären. Fehler und Unsicherheit bei der Nutzung von Modelloutputs in weiteren Analysen berücksichtigen.

**Rein operative Analytik oder Methodenforschung:** Den Geltungsbereich des Reports erläutern. Nach dem wissenschaftlichen Erkenntnisziel fragen. Nicht auf eine erfundene populationsbezogene Forschungsfrage umlenken; eine vom User bestätigte Anpassung oder eingeschränkte Anwendbarkeit dokumentieren.

Vor Abschluss die 32 IDs durchgehen, aber nur fehlende oder unklare Punkte erneut erfragen. Die letzte Bestandsaufnahme und den Dokumentplan zeigen. Nach der Nutzerbestätigung ausschließlich bestätigte Inhalte und korrekt gekennzeichnete Pläne ausformulieren.
