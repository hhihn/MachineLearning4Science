# Projektprotokoll

## Zweck

Projektantworten nachvollziehbar speichern, offene Entscheidungen erkennen und die Word-Ausgabe steuern. Keine Datenbank oder automatische Erinnerung behaupten. Ein lokaler JSON-Zustand ist ein Arbeitsmittel innerhalb der verfügbaren Dateiumgebung.

Das Protokoll ist kein Ersatz für das Gespräch. Insbesondere kann ein technischer Validator nicht erkennen, ob eine Antwort wahr ist oder ob der Assistent ein Zitat erfunden hat. Vor dem Export den tatsächlichen Dialog und die fachliche Konsistenz prüfen.

## Anlegen

Im Skill-Verzeichnis ausführen, unter Verwendung des in der Umgebung vorgesehenen Python-Runtimes:

```bash
python scripts/concept.py init /absolute/path/project-state.json
```

Die Initialisierung lässt alle Felder unbeantwortet und setzt keine Sprache, Fallzahl, Methode oder Voreinstellung für eine Studie.

## Aufbau

- `revision`: positive ganze Zahl; nach jeder inhaltlichen Änderung erhöhen.
- `core`: alle grundlegenden Felder aus `catalog.json`, indiziert nach ihrer ID.
- `items`: genau die 32 Report-IDs, indiziert nach ihrer ID.
- `conflicts`: Liste methodischer oder faktischer Widersprüche. Jeder hat `description`, `status` als `open` oder `resolved` und bei Auflösung `resolution`.
- `final_review`: `status`, `reviewed_revision`, `reviewed_digest`, `user_evidence`. Nur nach ausdrücklicher Bestätigung des konkret vorgelegten aktuellen Konzeptstands ausfüllen. `reviewed_digest` bindet die Bestätigung an dessen exakten Inhalt.
- `labels`: für die gewählte Dokumentsprache lokalisierte Beschriftungen. Mit `concept.py labels de` oder `concept.py labels en` eine Sprachvorlage ausgeben; für andere Sprachen alle Texte und Titel übersetzen. Nicht die Projektantworten verändern.

Jedes Feld in `core` enthält:

```json
{
  "status": "unanswered",
  "text": "",
  "user_evidence": [],
  "rationale": ""
}
```

Jedes Feld in `items` enthält zusätzlich:

```json
{
  "implementation_status": "",
  "evidence_plan": ""
}
```

## Statuswerte

- `unanswered`: noch nicht beantwortet.
- `proposed`: vom Assistenten vorgeschlagen, nicht ausgewählt.
- `deferred`: nach Rückfrage bewusst zurückgestellt; weiterhin offen.
- `conflict`: widersprüchlich oder methodisch ungeklärt.
- `confirmed`: eindeutig vom User beantwortet beziehungsweise ausdrücklich ausgewählt.
- `not_applicable`: nur für einzelne REFORMS-Items, mit fachlicher Begründung und expliziter Nutzerbestätigung.

Nichtanwendbarkeit nicht für ganze Module oder grundlegende Projektfelder pauschal einsetzen. Einen Wert wie „ML dient hier der explorativen Struktursuche; es gibt keinen prospektiven Vorhersagezeitpunkt“ als konkrete Antwort zum Informationskontext erfassen, statt ein Pflichtfeld zu löschen.

`user_evidence` ist eine Liste nichtleerer Strings mit tatsächlichen Nutzerzitaten oder präzisen Fundstellen samt expliziter Bestätigung. Falls keine Nachrichten-ID verfügbar ist, die Frage und tatsächliche Antwort benennen. Keine erfundene Kennung als Nachweis verwenden. Dieselbe echte Antwort darf mehrere Items stützen. Eine Nutzerentscheidung ist kein Beleg für die erfolgreiche Umsetzung.

`implementation_status` ist `planned`, `existing` oder `not_applicable`. Für bestätigte Items `planned` oder `existing` wählen. Bei einem noch nicht durchgeführten Projekt explizit den vereinbarten Plan dokumentieren. `evidence_plan` beschreibt den existierenden Nachweis oder den konkret vereinbarten nächsten Nachweis; keine Ergebnisse ergänzen. Bei Nichtanwendbarkeit ebenfalls den Grund dokumentieren.

`rationale` erklärt für jedes Item, warum die Entscheidung zur Studie passt beziehungsweise weshalb der Punkt nicht anwendbar ist. „Standard“ oder „vom Plugin gewählt“ ist keine hinreichende Nutzerentscheidung.

## Aktualisieren

1. Explizite Nutzerantwort in eigenen Worten präzise erfassen und einen echten Beleg hinzufügen.
2. Bei unklarer Auslegung nachfragen; vor einer Antwort auf `proposed` belassen.
3. Bei einer Änderung `revision` erhöhen, `final_review` zurücksetzen und die fachlich abhängigen Einträge erneut prüfen. Betroffene frühere Bestätigungen nicht unverändert als aktuell ausgeben.
4. Unbekannte Mengen oder noch fehlende deskriptive Statistiken nicht ersetzen. Mit dem User festlegen, wie sie erhoben werden; einen ausreichend konkreten Plan als solchen erfassen. Das ersetzt keine aktuell erforderliche Grundentscheidung wie das Generalisierungsziel oder die Auswahlmetrik.
5. Das Dokument in der gewählten Dokumentsprache ausformulieren. Nutzerzitate in der Originalsprache erhalten. Die Beschriftungen aus `labels` müssen dieselbe Sprache verwenden. In `labels.language` die tatsächliche Bezeichnung aus `core.document_language.text` übernehmen.

## Prüfen und exportieren

Vor dem Vorlegen des konkreten Abschlussstands dessen Fingerabdruck bestimmen. Nach der tatsächlichen Nutzerbestätigung diesen Wert unter `final_review.reviewed_digest`, die Revision unter `reviewed_revision` und den echten Nutzerbeleg unter `user_evidence` eintragen. Danach keine inhaltlichen Änderungen ohne erneute Bestätigung vornehmen.

```bash
python scripts/concept.py fingerprint /absolute/path/project-state.json
python scripts/concept.py check /absolute/path/project-state.json
python scripts/concept.py export /absolute/path/project-state.json /absolute/path/Research_Concept.docx
```

`check` gibt alle offenen oder fehlerhaften Felder aus und beendet sich bei nicht erfülltem Abschluss mit Exitcode 2. `export` erzeugt standardmäßig nur bei bestandener struktureller Prüfung eine Datei.

Einen Arbeitsstand ausschließlich auf ausdrücklichen Nutzerwunsch exportieren:

```bash
python scripts/concept.py export /absolute/path/project-state.json /absolute/path/Research_Concept_Draft.docx --draft
```

Die Entwurfsoption macht offene Punkte sichtbar; sie macht sie nicht erledigt. Sie darf nicht verwendet werden, um die Anforderung an beantwortete Grundfragen bei einem abschließenden Dokument zu umgehen.
