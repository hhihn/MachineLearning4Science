# Quellen und Einordnung

## Bereitgestellte Grundlage

Der beigefügte Text „Das REFORMS Framework Umfassender Leitfaden Best Practices und Walkthrough für ML basierte Wissenschaft“ ist als `source-report.txt` enthalten. Die Gliederung der 32 Prüfpunkte und die daraus entwickelten Fragen orientieren sich an diesem Nutzerreport. Seine Beispiele sind keine Fakten über das Projekt der Forschenden.

## Verifizierte Originalpublikation

Kapoor S et al. 2024. REFORMS Consensus-based Recommendations for Machine-learning-based Science. Science Advances 10 eadk3452.

- DOI: https://doi.org/10.1126/sciadv.adk3452
- Volltext: https://pmc.ncbi.nlm.nih.gov/articles/PMC11092361/
- Maßgebliche Zuordnung der Item-IDs: Tabelle 1.
- Prüfung der Item-Zuordnung: 1. November 2026.

Die Originalpublikation bestätigt acht Module und 32 Items und lässt eine begründete studienspezifische Anwendung zu. Hier wird eine Planungshilfe aus dem Nutzerreport umgesetzt. Keine offizielle REFORMS-Zertifizierung oder Verbindung zu den Autor*innen behaupten.

## Eigene Operationalisierung

Sokratische Gesprächsregeln, Projektprotokoll, Pflichtfelder, Exportprüfungen und Word-Struktur sind für diesen Plugin-Auftrag entwickelte Hilfen. Sie sind keine zusätzlichen Original-Items. `methodology.md` präzisiert insbesondere die Trennung von Entwicklung und unabhängiger Evaluation sowie den Unterschied zwischen Planung, Durchführung und Nachweis.

Den gesamten Originalartikel nicht in Ausgaben kopieren. Bei zusätzlicher Literaturrecherche nach Bedarf tatsächliche Primärquellen prüfen und nachprüfbar zitieren; keine Referenzen aus dem Report als selbst gelesen darstellen. Vorhandene wissenschaftliche Projektliteratur vom User erfragen. Ungeprüfte Detailbehauptungen und Zahlenbeispiele des Reports nicht ungefragt in Nutzerkonzepte übertragen.
